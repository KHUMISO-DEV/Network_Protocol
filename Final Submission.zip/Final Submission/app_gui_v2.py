"""
Chat App GUI — Tkinter front-end that wraps Server, Client, and P2PClient.
Run this file directly:  python app_gui.py
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog, simpledialog
import threading
import socket
import os
import time
import json

from Server import Server
from Client import Client
from p2p_prototype_with_media import P2PClient

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"


# ─────────────────────────────────────────────────────────────────────────────
# Login Window
# ─────────────────────────────────────────────────────────────────────────────

class LoginWindow(tk.Toplevel):
    def __init__(self, master, on_login):
        super().__init__(master)
        self.title("Login")
        self.resizable(False, False)
        self.on_login = on_login
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", master.destroy)

        pad = {"padx": 10, "pady": 5}

        tk.Label(self, text="Chat Application", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(15, 5))

        tk.Label(self, text="Username:").grid(row=1, column=0, sticky="e", **pad)
        self.user_var = tk.StringVar()
        tk.Entry(self, textvariable=self.user_var, width=22).grid(row=1, column=1, **pad)

        tk.Label(self, text="Password:").grid(row=2, column=0, sticky="e", **pad)
        self.pass_var = tk.StringVar()
        tk.Entry(self, textvariable=self.pass_var, show="*", width=22).grid(row=2, column=1, **pad)

        tk.Label(self, text="Server IP:").grid(row=3, column=0, sticky="e", **pad)
        self.ip_var = tk.StringVar(value="127.0.0.1")
        tk.Entry(self, textvariable=self.ip_var, width=22).grid(row=3, column=1, **pad)

        tk.Label(self, text="Server Port:").grid(row=4, column=0, sticky="e", **pad)
        self.port_var = tk.StringVar(value="5005")
        tk.Entry(self, textvariable=self.port_var, width=22).grid(row=4, column=1, **pad)

        tk.Label(self, text="My P2P Port:").grid(row=5, column=0, sticky="e", **pad)
        self.p2p_port_var = tk.StringVar(value="5100")
        tk.Entry(self, textvariable=self.p2p_port_var, width=22).grid(row=5, column=1, **pad)

        self.public_var = tk.BooleanVar(value=True)
        tk.Checkbutton(self, text="Appear in public user list", variable=self.public_var).grid(
            row=6, column=0, columnspan=2, pady=4)

        self.err_lbl = tk.Label(self, text="", fg="red")
        self.err_lbl.grid(row=7, column=0, columnspan=2)

        btn_frame = tk.Frame(self)
        btn_frame.grid(row=8, column=0, columnspan=2, pady=10)
        tk.Button(btn_frame, text="Login", width=10, command=self._login).pack(side="left", padx=5)
        tk.Button(btn_frame, text="Register", width=10, command=self._do_register).pack(side="left", padx=5)

        self.bind("<Return>", lambda e: self._login())

    def _login(self):
        username = self.user_var.get().strip()
        password = self.pass_var.get().strip()
        if not username or not password:
            self.err_lbl.config(text="Username and password required.")
            return
        if self._check_credentials(username, password):
            self.on_login(
                username,
                self.ip_var.get().strip(),
                int(self.port_var.get().strip()),
                int(self.p2p_port_var.get().strip()),
                self.public_var.get()
            )
            self.destroy()
        else:
            self.err_lbl.config(text="Invalid credentials.")

    def _do_register(self):
        username = self.user_var.get().strip()
        password = self.pass_var.get().strip()
        if not username or not password:
            self.err_lbl.config(text="Enter username and password to register.")
            return
        users = self._load_users()
        if username in users:
            self.err_lbl.config(text="Username already taken.")
            return
        users[username] = password
        self._save_users(users)
        self.err_lbl.config(text="Registered! You can now log in.", fg="green")

    def _check_credentials(self, username, password):
        users = self._load_users()
        return users.get(username) == password

    def _load_users(self):
        users = {}
        try:
            with open("users.txt", "r") as f:
                for line in f:
                    line = line.strip()
                    if ',' in line:
                        u, p = line.split(",", 1)
                        users[u] = p
        except FileNotFoundError:
            pass
        return users

    def _save_users(self, users):
        with open("users.txt", "w") as f:
            for u, p in users.items():
                f.write(f"{u},{p}\n")


# ─────────────────────────────────────────────────────────────────────────────
# Server Management Window
# ─────────────────────────────────────────────────────────────────────────────

class ServerWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Server Manager")
        self.geometry("520x340")
        self.server = None
        self.server_thread = None
        self._build_ui()

    def _build_ui(self):
        top = tk.Frame(self)
        top.pack(fill="x", padx=10, pady=8)

        tk.Label(top, text="Port:").pack(side="left")
        self.port_var = tk.StringVar(value="5005")
        tk.Entry(top, textvariable=self.port_var, width=8).pack(side="left", padx=4)

        self.start_btn = tk.Button(top, text="Start Server", command=self._start, bg="#4CAF50", fg="white")
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn = tk.Button(top, text="Stop Server", command=self._stop, bg="#f44336", fg="white", state="disabled")
        self.stop_btn.pack(side="left", padx=4)

        self.status_lbl = tk.Label(top, text="● Stopped", fg="red")
        self.status_lbl.pack(side="left", padx=10)

        self.ip_lbl = tk.Label(self, text=f"Local IP: {get_local_ip()}", font=("Arial", 9))
        self.ip_lbl.pack(anchor="w", padx=10)

        tk.Label(self, text="Server Log:").pack(anchor="w", padx=10)
        self.log_box = scrolledtext.ScrolledText(self, height=14, state="disabled", font=("Courier", 9))
        self.log_box.pack(fill="both", expand=True, padx=10, pady=5)

    def _log(self, msg):
        self.log_box.config(state="normal")
        self.log_box.insert("end", msg + "\n")
        self.log_box.see("end")
        self.log_box.config(state="disabled")

    def _start(self):
        port = int(self.port_var.get())
        try:
            self.server = Server(port=port)
            self.server.set_log_callback(lambda m: self.after(0, self._log, m))
            self.server_thread = threading.Thread(target=self.server.run, daemon=True)
            self.server_thread.start()
            self.status_lbl.config(text=f"● Running on :{port}", fg="green")
            self.start_btn.config(state="disabled")
            self.stop_btn.config(state="normal")
            self._log(f"[SERVER] Started on port {port}. IP: {get_local_ip()}")
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self)

    def _stop(self):
        if self.server:
            try:
                self.server.server_socket.close()
            except:
                pass
            self.server = None
        self.status_lbl.config(text="● Stopped", fg="red")
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self._log("[SERVER] Stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# Connection Request Dialog
# ─────────────────────────────────────────────────────────────────────────────

class ConnectRequestDialog(tk.Toplevel):
    def __init__(self, master, from_user, ip, port, on_response):
        super().__init__(master)
        self.title("Incoming Connection Request")
        self.resizable(False, False)
        self.grab_set()
        self.on_response = on_response
        self.from_user = from_user

        tk.Label(self, text=f"'{from_user}' wants to connect with you.", font=("Arial", 11), pady=10).pack()
        tk.Label(self, text=f"Their IP: {ip}   P2P Port: {port}", font=("Courier", 10)).pack()

        btn_f = tk.Frame(self)
        btn_f.pack(pady=12)
        tk.Button(btn_f, text="Accept", width=10, bg="#4CAF50", fg="white",
                  command=lambda: self._respond(True)).pack(side="left", padx=8)
        tk.Button(btn_f, text="Decline", width=10, bg="#f44336", fg="white",
                  command=lambda: self._respond(False)).pack(side="left", padx=8)

    def _respond(self, accepted):
        self.on_response(self.from_user, accepted)
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
# Main Chat Window
# ─────────────────────────────────────────────────────────────────────────────

class ChatApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Chat Application")
        self.geometry("900x620")
        self.minsize(700, 480)

        # State
        self.username = ""
        self.server_ip = ""
        self.server_port = 5005
        self.p2p_port = 5100
        self.is_public = True
        self.client: Client = None
        self.p2p_client: P2PClient = None
        self.p2p_peer_username = ""
        self.online_users = []           # list of {"username", "ip", "p2p_port"}
        self.private_target = None
        self._ping_running = False

        self._build_ui()
        self.after(100, self._show_login)

    # ──────────────────────────────── UI BUILD ────────────────────────────────

    def _build_ui(self):
        # Menu bar
        menubar = tk.Menu(self)
        app_menu = tk.Menu(menubar, tearoff=0)
        app_menu.add_command(label="Start/Manage Server", command=self._open_server_window)
        app_menu.add_command(label="Disconnect", command=self._disconnect)
        app_menu.add_separator()
        app_menu.add_command(label="Quit", command=self.destroy)
        menubar.add_cascade(label="App", menu=app_menu)
        self.config(menu=menubar)

        # Top status bar
        status_bar = tk.Frame(self, bg="#2b2b2b", height=28)
        status_bar.pack(fill="x")
        status_bar.pack_propagate(False)
        self.conn_lbl = tk.Label(status_bar, text="Not connected", fg="#aaa", bg="#2b2b2b", font=("Arial", 9))
        self.conn_lbl.pack(side="left", padx=10)
        self.mode_lbl = tk.Label(status_bar, text="", fg="#6af", bg="#2b2b2b", font=("Arial", 9))
        self.mode_lbl.pack(side="left", padx=6)

        # Visibility toggle
        self.pub_var = tk.BooleanVar(value=True)
        pub_cb = tk.Checkbutton(status_bar, text="Public", variable=self.pub_var,
                                command=self._toggle_visibility, fg="white", bg="#2b2b2b",
                                selectcolor="#2b2b2b", activebackground="#2b2b2b", activeforeground="white")
        pub_cb.pack(side="right", padx=10)

        # Main content area
        paned = tk.PanedWindow(self, orient="horizontal", sashwidth=4, bg="#888")
        paned.pack(fill="both", expand=True)

        # LEFT: user list
        left_frame = tk.Frame(paned, width=180, bg="#f0f0f0")
        left_frame.pack_propagate(False)
        paned.add(left_frame, minsize=140)

        tk.Label(left_frame, text="Online Users", font=("Arial", 10, "bold"), bg="#f0f0f0").pack(pady=(8, 2))
        self.user_listbox = tk.Listbox(left_frame, font=("Arial", 10), selectmode="single",
                                       activestyle="none", relief="flat", bg="#f0f0f0")
        self.user_listbox.pack(fill="both", expand=True, padx=6, pady=4)
        self.user_listbox.bind("<Double-Button-1>", self._on_user_double_click)

        btn_frame_left = tk.Frame(left_frame, bg="#f0f0f0")
        btn_frame_left.pack(fill="x", padx=6, pady=4)
        tk.Button(btn_frame_left, text="Connect (P2P)", command=self._request_p2p_connect,
                  font=("Arial", 9)).pack(fill="x", pady=2)
        tk.Button(btn_frame_left, text="Private Msg", command=self._set_private_target,
                  font=("Arial", 9)).pack(fill="x", pady=2)

        # RIGHT: chat
        right_frame = tk.Frame(paned)
        paned.add(right_frame, minsize=400)

        # Chat tabs
        self.tab_control = ttk.Notebook(right_frame)
        self.tab_control.pack(fill="both", expand=True, padx=4, pady=(4, 0))

        # Group chat tab
        self.group_frame = tk.Frame(self.tab_control)
        self.tab_control.add(self.group_frame, text="Group Chat")
        self.group_box = scrolledtext.ScrolledText(self.group_frame, state="disabled",
                                                    font=("Arial", 10), wrap="word")
        self.group_box.pack(fill="both", expand=True)
        self.group_box.tag_config("me", foreground="#1a6bb5", font=("Arial", 10, "bold"))
        self.group_box.tag_config("other", foreground="#444")
        self.group_box.tag_config("system", foreground="#888", font=("Arial", 9, "italic"))

        # P2P tab
        self.p2p_frame = tk.Frame(self.tab_control)
        self.tab_control.add(self.p2p_frame, text="P2P / Media")
        self._build_p2p_tab()

        # Private chat tab
        self.private_frame = tk.Frame(self.tab_control)
        self.tab_control.add(self.private_frame, text="Private Chat")
        self._build_private_tab()

        # Bottom input area
        bottom = tk.Frame(right_frame)
        bottom.pack(fill="x", padx=4, pady=4)

        self.target_lbl = tk.Label(bottom, text="[Group]", fg="#888", font=("Arial", 9))
        self.target_lbl.pack(side="left")

        self.msg_var = tk.StringVar()
        self.msg_entry = tk.Entry(bottom, textvariable=self.msg_var, font=("Arial", 11))
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=(4, 4))
        self.msg_entry.bind("<Return>", lambda e: self._send_message())

        tk.Button(bottom, text="Send", width=8, command=self._send_message,
                  bg="#1a6bb5", fg="white").pack(side="left")

    def _build_p2p_tab(self):
        info_frame = tk.Frame(self.p2p_frame, bg="#eef2ff", relief="groove", bd=1)
        info_frame.pack(fill="x", padx=8, pady=8)
        info_top = tk.Frame(info_frame, bg="#eef2ff")
        info_top.pack(fill="x", padx=8, pady=(4, 0))
        tk.Label(info_top, text="P2P Session Info", font=("Arial", 10, "bold"), bg="#eef2ff").pack(side="left")
        self.end_p2p_btn = tk.Button(info_top, text="✕ End P2P Session", command=self._end_p2p,
                                     bg="#f44336", fg="white", font=("Arial", 9), state="disabled")
        self.end_p2p_btn.pack(side="right")
        self.p2p_status_lbl = tk.Label(info_frame, text="No active P2P session.", fg="#888", bg="#eef2ff")
        self.p2p_status_lbl.pack(anchor="w", padx=8, pady=(0, 4))

        tk.Label(self.p2p_frame, text="P2P Chat:").pack(anchor="w", padx=8)
        self.p2p_box = scrolledtext.ScrolledText(self.p2p_frame, state="disabled",
                                                  font=("Arial", 10), wrap="word", height=10)
        self.p2p_box.pack(fill="both", expand=True, padx=8)
        self.p2p_box.tag_config("me", foreground="#1a6bb5", font=("Arial", 10, "bold"))
        self.p2p_box.tag_config("other", foreground="#444")
        self.p2p_box.tag_config("system", foreground="#888", font=("Arial", 9, "italic"))

        media_frame = tk.Frame(self.p2p_frame)
        media_frame.pack(fill="x", padx=8, pady=6)
        tk.Button(media_frame, text="📎 Send File", command=self._send_media,
                  bg="#7c4dff", fg="white", font=("Arial", 10)).pack(side="left", padx=4)
        self.media_status_lbl = tk.Label(media_frame, text="", fg="#555", font=("Arial", 9))
        self.media_status_lbl.pack(side="left", padx=6)

    def _build_private_tab(self):
        self.private_target_lbl = tk.Label(self.private_frame, text="No target selected.",
                                            fg="#888", font=("Arial", 9, "italic"))
        self.private_target_lbl.pack(anchor="w", padx=8, pady=(6, 0))
        self.private_box = scrolledtext.ScrolledText(self.private_frame, state="disabled",
                                                      font=("Arial", 10), wrap="word")
        self.private_box.pack(fill="both", expand=True, padx=8, pady=4)
        self.private_box.tag_config("me", foreground="#1a6bb5", font=("Arial", 10, "bold"))
        self.private_box.tag_config("other", foreground="#444")
        self.private_box.tag_config("system", foreground="#888", font=("Arial", 9, "italic"))

    # ──────────────────────────────── LOGIN ────────────────────────────────

    def _show_login(self):
        LoginWindow(self, self._on_login)

    def _on_login(self, username, server_ip, server_port, p2p_port, public):
        self.username = username
        self.server_ip = server_ip
        self.server_port = server_port
        self.p2p_port = p2p_port
        self.is_public = public
        self.pub_var.set(public)
        self._connect_to_server()

    def _connect_to_server(self):
        try:
            self.client = Client(self.server_ip, self.server_port)
            self.client.login(self.username, self.is_public, self.p2p_port)
            self.client.run(callback=self._on_server_msg)
            self.conn_lbl.config(text=f"Connected as {self.username} @ {self.server_ip}:{self.server_port}", fg="#4f4")
            self._append_chat(self.group_box, f"[SYSTEM] Connected to server {self.server_ip}:{self.server_port}.", "system")
            self._start_ping()
        except Exception as e:
            messagebox.showerror("Connection Failed", str(e))
            self.conn_lbl.config(text="Not connected", fg="#f44")

    # ──────────────────────────────── SERVER MESSAGES ──────────────────────────

    def _on_server_msg(self, msg):
        """Called from background thread — must use after() to touch GUI."""
        self.after(0, self._handle_server_msg, msg)

    def _handle_server_msg(self, msg):
        mtype = msg.get("type", "")

        if mtype == "LOGIN_OK":
            self._append_chat(self.group_box, f"[SERVER] {msg.get('message','')}", "system")

        elif mtype == "USER_LIST":
            self.online_users = msg.get("users", [])
            self._refresh_user_list()

        elif mtype == "GROUP_MSG":
            sender = msg.get("sender", "?")
            text = msg.get("text", "")
            tag = "me" if sender == self.username else "other"
            self._append_chat(self.group_box, f"{sender}: {text}", tag)

        elif mtype == "PRIVATE_MSG":
            sender = msg.get("sender", "?")
            text = msg.get("text", "")
            self._append_chat(self.private_box, f"{sender}: {text}", "other")
            # Auto-switch to private tab and set target
            if self.private_target != sender:
                self.private_target = sender
                self.private_target_lbl.config(text=f"Chatting with: {sender}")
                self.target_lbl.config(text=f"[Private → {sender}]")
            self.tab_control.select(self.private_frame)

        elif mtype == "SYSTEM":
            self._append_chat(self.group_box, msg.get("text", ""), "system")

        elif mtype == "CONNECT_REQUEST":
            from_user = msg.get("from", "?")
            ip = msg.get("ip", "?")
            port = msg.get("p2p_port", 5100)
            ConnectRequestDialog(self, from_user, ip, port,
                                 lambda u, acc: self._respond_p2p(u, acc, ip, port))

        elif mtype == "CONNECT_RESPONSE":
            from_user = msg.get("from", "?")
            accepted = msg.get("accepted", False)
            ip = msg.get("ip", "?")
            port = msg.get("p2p_port", 5100)
            if accepted:
                self._append_chat(self.p2p_box, f"[SYSTEM] {from_user} accepted! Starting P2P...", "system")
                self._start_p2p(from_user, ip, port)
            else:
                self._append_chat(self.group_box, f"[SYSTEM] {from_user} declined the connection.", "system")

        elif mtype == "PONG":
            pass  # keep-alive acknowledged

    # ──────────────────────────────── USER LIST ──────────────────────────────

    def _refresh_user_list(self):
        self.user_listbox.delete(0, "end")
        for u in self.online_users:
            uname = u["username"]
            marker = " ●" if uname == self.username else ""
            self.user_listbox.insert("end", uname + marker)

    def _on_user_double_click(self, event):
        sel = self.user_listbox.curselection()
        if not sel:
            return
        name = self.user_listbox.get(sel[0]).replace(" ●", "")
        if name == self.username:
            return
        # Open dialog to choose action
        action = self._user_action_dialog(name)
        if action == "p2p":
            self._send_connect_request(name)
        elif action == "private":
            self.private_target = name
            self.private_target_lbl.config(text=f"Chatting with: {name}")
            self.target_lbl.config(text=f"[Private → {name}]")
            self.tab_control.select(self.private_frame)

    def _user_action_dialog(self, name):
        dlg = tk.Toplevel(self)
        dlg.title(f"Connect to {name}")
        dlg.resizable(False, False)
        dlg.grab_set()
        result = tk.StringVar(value="")
        tk.Label(dlg, text=f"What would you like to do with {name}?", pady=8, padx=12).pack()
        btn_f = tk.Frame(dlg)
        btn_f.pack(pady=8)
        tk.Button(btn_f, text="Request P2P Connect", width=18,
                  command=lambda: (result.set("p2p"), dlg.destroy())).pack(side="left", padx=6)
        tk.Button(btn_f, text="Send Private Message", width=18,
                  command=lambda: (result.set("private"), dlg.destroy())).pack(side="left", padx=6)
        tk.Button(btn_f, text="Cancel", width=10,
                  command=lambda: (result.set(""), dlg.destroy())).pack(side="left", padx=6)
        dlg.wait_window()
        return result.get()

    # ──────────────────────────────── MESSAGING ──────────────────────────────

    def _send_message(self):
        text = self.msg_var.get().strip()
        if not text or not self.client:
            return
        self.msg_var.set("")

        # Determine current tab
        current_tab = self.tab_control.index(self.tab_control.select())

        if current_tab == 1 and self.p2p_client:
            # P2P chat
            self.p2p_client.send_chat(text)
            self._append_chat(self.p2p_box, f"{self.username}: {text}", "me")
            return

        if self.private_target and current_tab == 2:
            self.client.send_private(self.private_target, text)
            self._append_chat(self.private_box, f"{self.username}: {text}", "me")
            return

        # Default: group
        self.client.send_group(text)
        self._append_chat(self.group_box, f"{self.username}: {text}", "me")

    def _set_private_target(self):
        sel = self.user_listbox.curselection()
        if not sel:
            messagebox.showinfo("Select User", "Please select a user from the list first.")
            return
        name = self.user_listbox.get(sel[0]).replace(" ●", "")
        if name == self.username:
            return
        self.private_target = name
        self.private_target_lbl.config(text=f"Chatting with: {name}")
        self.target_lbl.config(text=f"[Private → {name}]")
        self.tab_control.select(self.private_frame)

    # ──────────────────────────────── P2P ────────────────────────────────────

    def _request_p2p_connect(self):
        sel = self.user_listbox.curselection()
        if not sel:
            messagebox.showinfo("Select User", "Select a user from the list first.")
            return
        name = self.user_listbox.get(sel[0]).replace(" ●", "")
        if name == self.username:
            return
        self._send_connect_request(name)

    def _send_connect_request(self, target):
        if not self.client:
            messagebox.showerror("Not Connected", "Connect to server first.")
            return
        # Show auto-filled dialog
        peer_info = next((u for u in self.online_users if u["username"] == target), None)
        if not peer_info:
            messagebox.showerror("User Not Found", f"'{target}' is not in the public list.")
            return

        dlg = tk.Toplevel(self)
        dlg.title("Send P2P Connection Request")
        dlg.resizable(False, False)
        dlg.grab_set()

        tk.Label(dlg, text=f"Requesting P2P connection to: {target}", font=("Arial", 11), pady=8, padx=12).pack()
        tk.Label(dlg, text=f"Their IP: {peer_info['ip']}   Their P2P Port: {peer_info['p2p_port']}",
                 font=("Courier", 10)).pack()
        tk.Label(dlg, text=f"Your P2P Port: {self.p2p_port}", font=("Courier", 10)).pack(pady=(0, 8))

        def confirm():
            self.client.send_connect_request(target)
            self._append_chat(self.group_box, f"[SYSTEM] Connection request sent to {target}.", "system")
            dlg.destroy()

        btn_f = tk.Frame(dlg)
        btn_f.pack(pady=8)
        tk.Button(btn_f, text="Send Request", bg="#4CAF50", fg="white", command=confirm).pack(side="left", padx=8)
        tk.Button(btn_f, text="Cancel", command=dlg.destroy).pack(side="left", padx=8)

    def _respond_p2p(self, from_user, accepted, peer_ip, peer_p2p_port):
        self.client.send_connect_response(from_user, accepted)
        if accepted:
            self._start_p2p(from_user, peer_ip, peer_p2p_port)
        else:
            self._append_chat(self.group_box, f"[SYSTEM] Declined connection from {from_user}.", "system")

    def _start_p2p(self, peer_username, peer_ip, peer_p2p_port):
        """Start UDP P2P session. TCP server remains running in background."""
        try:
            self.p2p_peer_username = peer_username
            self.p2p_client = P2PClient(
                username=self.username,
                local_port=self.p2p_port,
                peer_ip=peer_ip,
                peer_port=peer_p2p_port
            )

            # Override listener to route messages to GUI
            threading.Thread(target=self._p2p_listener, daemon=True).start()
            threading.Thread(target=self.p2p_client.resend_unacked, daemon=True).start()

            self.p2p_peer_port = peer_p2p_port
            self.p2p_status_lbl.config(
                text=f"Connected to {peer_username} @ {peer_ip}:{peer_p2p_port}  (your port: {self.p2p_port})",
                fg="green"
            )
            self.end_p2p_btn.config(state="normal")
            self.mode_lbl.config(text=f"[P2P: {peer_username}]")
            self._append_chat(self.p2p_box, f"[SYSTEM] P2P session started with {peer_username}.", "system")
            self.tab_control.select(self.p2p_frame)

        except Exception as e:
            messagebox.showerror("P2P Error", str(e))

    def _p2p_listener(self):
        p = self.p2p_client
        while p and p.running:
            try:
                data, addr = p.sock.recvfrom(4096)
                msg_type, seq, sender, extra, payload = p.parse_message(data)
                if msg_type is None:
                    continue

                if msg_type == "ACK":
                    with p.pending_acks_lock:
                        p.pending_acks.pop(seq, None)

                elif msg_type == "CHAT_MSG":
                    p.sock.sendto(p.build_header("ACK", seq), addr)
                    self.after(0, self._append_chat, self.p2p_box, f"{sender}: {extra}", "other")

                elif msg_type == "FILE_INFO":
                    filename, filesize_str = extra.split(":")
                    filesize = int(filesize_str)
                    if p.file_handle and not p.file_handle.closed:
                        p.file_handle.close()
                    save_path = "received_" + filename
                    p.file_handle = open(save_path, "wb")
                    p.expected_file_size = filesize
                    p.received_bytes = 0
                    p.receiving_file = True
                    p.sock.sendto(p.build_header("ACK", seq), addr)
                    self.after(0, lambda f=filename, s=filesize: (
                        self.media_status_lbl.config(text=f"Receiving: {f} ({s} bytes)..."),
                        self._append_chat(self.p2p_box, f"[SYSTEM] Receiving file: {f} ({s} bytes)...", "system")
                    ))

                elif msg_type == "FILE_DATA" and p.receiving_file:
                    p.file_handle.write(payload)
                    p.received_bytes += len(payload)
                    p.sock.sendto(p.build_header("ACK", seq), addr)
                    if p.received_bytes >= p.expected_file_size:
                        fname = p.file_handle.name
                        p.file_handle.close()
                        p.receiving_file = False
                        self.after(0, lambda f=fname: (
                            self.media_status_lbl.config(text=f"Saved: {f}"),
                            self._append_chat(self.p2p_box, f"[SYSTEM] File received and saved as '{f}'.", "system")
                        ))

            except Exception:
                continue

    def _end_p2p(self):
        """Cleanly tear down the current P2P session so a new one can be started."""
        if self.p2p_client:
            self.p2p_client.running = False
            try:
                self.p2p_client.sock.close()
            except Exception:
                pass
            self.p2p_client = None
        self.p2p_peer_username = ""
        self.p2p_status_lbl.config(text="No active P2P session.", fg="#888")
        self.end_p2p_btn.config(state="disabled")
        self.media_status_lbl.config(text="")
        self.mode_lbl.config(text="")
        self._append_chat(self.p2p_box, "[SYSTEM] P2P session ended. You can now connect to a new peer.", "system")

    def _send_media(self):
        if not self.p2p_client:
            messagebox.showerror("No P2P Session", "Establish a P2P connection first.")
            return
        path = filedialog.askopenfilename(title="Select file to send")
        if not path:
            return
        self.media_status_lbl.config(text=f"Sending: {os.path.basename(path)}...")
        self._append_chat(self.p2p_box, f"[SYSTEM] Sending file: {os.path.basename(path)}...", "system")
        threading.Thread(target=self._do_send_file, args=(path,), daemon=True).start()

    def _do_send_file(self, path):
        self.p2p_client.send_file(path)
        self.after(0, lambda: (
            self.media_status_lbl.config(text=f"Sent: {os.path.basename(path)}"),
            self._append_chat(self.p2p_box, f"[SYSTEM] File sent: {os.path.basename(path)}", "system")
        ))

    # ──────────────────────────────── VISIBILITY ─────────────────────────────

    def _toggle_visibility(self):
        if not self.client:
            return
        public = self.pub_var.get()
        self.is_public = public
        self.client.set_visibility(public, self.p2p_port)
        status = "public" if public else "private"
        self._append_chat(self.group_box, f"[SYSTEM] You are now {status}.", "system")

    # ──────────────────────────────── PING ───────────────────────────────────

    def _start_ping(self):
        if self._ping_running:
            return
        self._ping_running = True
        threading.Thread(target=self._ping_loop, daemon=True).start()

    def _ping_loop(self):
        while self._ping_running and self.client and self.client.ping:
            time.sleep(10)
            if self.client and self.client.ping:
                self.client.send_ping()

    # ──────────────────────────────── MISC ───────────────────────────────────

    def _append_chat(self, box, text, tag="other"):
        box.config(state="normal")
        box.insert("end", text + "\n", tag)
        box.see("end")
        box.config(state="disabled")

    def _disconnect(self):
        self._ping_running = False
        if self.client:
            self.client.disconnect()
            self.client = None
        if self.p2p_client:
            self.p2p_client.running = False
            self.p2p_client = None
        self.conn_lbl.config(text="Not connected", fg="#f44")
        self.mode_lbl.config(text="")

    def _open_server_window(self):
        ServerWindow(self)


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = ChatApp()
    app.mainloop()
