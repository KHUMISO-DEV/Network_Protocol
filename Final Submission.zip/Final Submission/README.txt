=== Chat Application GUI ===

FILES:
  app_gui.py                   — Main GUI (run this)
  Server.py                    — Server (now JSON-protocol based)
  Client.py                    — TCP Client (JSON-protocol)
  p2p_prototype_with_media.py  — UDP P2P layer (unchanged logic)
  users.txt                    — User credentials (user,password per line)

HOW TO RUN:
  python app_gui.py

TO START THE SERVER:
  Option A: From the GUI → App menu → "Start/Manage Server"
  Option B: python Server.py   (standalone)

CREDENTIALS (sample):
  alice / alice123
  bob / bob123
  admin / admin

FEATURES:
  ✓ Login / Register
  ✓ Start/stop server from GUI
  ✓ Group chat broadcast
  ✓ Private 1-to-1 messaging
  ✓ Online user list with periodic refresh
  ✓ Public/Private visibility toggle
  ✓ P2P connection request → accept/decline dialog
  ✓ IP and port auto-filled from server user registry
  ✓ File/media transfer over UDP P2P
  ✓ Server stays live during P2P sessions
