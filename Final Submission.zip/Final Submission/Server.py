import socket
import threading
import json


class Server:
    def __init__(self, host='0.0.0.0', port=5005):
        self.host = host
        self.port = port
        self.clients = {}
        self.clients_lock = threading.Lock()
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(10)
        self._log_callback = None

    def set_log_callback(self, cb):
        self._log_callback = cb

    def log(self, message):
        print(message)
        if self._log_callback:
            self._log_callback(message)

    def get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            try:
                return socket.gethostbyname(socket.gethostname())
            except:
                return "127.0.0.1"

    def _send_json(self, conn, obj):
        try:
            data = json.dumps(obj)
            conn.send((data + "\n").encode('utf-8'))
            return True
        except:
            return False

    def _get_conn_by_username(self, username):
        with self.clients_lock:
            for conn, info in self.clients.items():
                if info["username"] == username and info["ping"]:
                    return conn
        return None

    def broadcast_user_list(self):
        with self.clients_lock:
            public_users = [
                {"username": info["username"], "ip": info["addr"][0], "p2p_port": info.get("p2p_port", 5100)}
                for info in self.clients.values()
                if info["public"] and info["ping"]
            ]
            all_conns = list(self.clients.keys())
        msg = {"type": "USER_LIST", "users": public_users}
        for conn in all_conns:
            self._send_json(conn, msg)

    def broadcast_group(self, message, sender_conn=None, sender_name=""):
        with self.clients_lock:
            snapshot = list(self.clients.items())
        for conn, info in snapshot:
            if conn != sender_conn and info["ping"]:
                self._send_json(conn, {"type": "GROUP_MSG", "sender": sender_name, "text": message})

    def handle_client(self, conn, addr):
        buffer = ""
        username = None
        try:
            conn.settimeout(15)
            raw = conn.recv(4096).decode('utf-8')
            conn.settimeout(None)
            for line in raw.strip().split("\n"):
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except:
                    continue
                if msg.get("type") == "LOGIN":
                    username = msg.get("username", "unknown")
                    public = msg.get("public", True)
                    p2p_port = msg.get("p2p_port", 5100)
                    with self.clients_lock:
                        self.clients[conn] = {
                            "username": username, "addr": addr,
                            "public": public, "ping": True, "p2p_port": p2p_port
                        }
                    self._send_json(conn, {"type": "LOGIN_OK", "message": f"Welcome, {username}!"})
                    self.log(f"[NEW CONNECTION] {username} @ {addr[0]}:{addr[1]}")
                    self.broadcast_user_list()
                    break

            if username is None:
                conn.close()
                return

            while True:
                with self.clients_lock:
                    active = self.clients.get(conn, {}).get("ping", False)
                if not active:
                    break
                try:
                    chunk = conn.recv(4096).decode('utf-8')
                    if not chunk:
                        break
                    buffer += chunk
                except (OSError, ConnectionResetError):
                    break

                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                    except:
                        continue
                    mtype = msg.get("type", "")

                    if mtype == "PING":
                        self._send_json(conn, {"type": "PONG"})

                    elif mtype == "SET_VISIBILITY":
                        public = msg.get("public", True)
                        p2p_port = msg.get("p2p_port", 5100)
                        with self.clients_lock:
                            if conn in self.clients:
                                self.clients[conn]["public"] = public
                                self.clients[conn]["p2p_port"] = p2p_port
                        self.broadcast_user_list()

                    elif mtype == "GROUP_MSG":
                        text = msg.get("text", "")
                        self.log(f"[GROUP] {username}: {text}")
                        self.broadcast_group(text, sender_conn=conn, sender_name=username)

                    elif mtype == "PRIVATE_MSG":
                        target = msg.get("target", "")
                        text = msg.get("text", "")
                        target_conn = self._get_conn_by_username(target)
                        if target_conn:
                            self._send_json(target_conn, {"type": "PRIVATE_MSG", "sender": username, "text": text})
                        else:
                            self._send_json(conn, {"type": "SYSTEM", "text": f"User '{target}' not found."})

                    elif mtype == "CONNECT_REQUEST":
                        target = msg.get("target", "")
                        target_conn = self._get_conn_by_username(target)
                        if target_conn:
                            with self.clients_lock:
                                req_info = self.clients.get(conn, {})
                            self._send_json(target_conn, {
                                "type": "CONNECT_REQUEST", "from": username,
                                "ip": addr[0], "p2p_port": req_info.get("p2p_port", 5100)
                            })
                        else:
                            self._send_json(conn, {"type": "SYSTEM", "text": f"User '{target}' not found."})

                    elif mtype == "CONNECT_RESPONSE":
                        target = msg.get("target", "")
                        accepted = msg.get("accepted", False)
                        target_conn = self._get_conn_by_username(target)
                        if target_conn:
                            with self.clients_lock:
                                resp_info = self.clients.get(conn, {})
                            self._send_json(target_conn, {
                                "type": "CONNECT_RESPONSE", "from": username,
                                "accepted": accepted, "ip": addr[0],
                                "p2p_port": resp_info.get("p2p_port", 5100)
                            })
        except Exception as e:
            self.log(f"[ERROR] Client {addr}: {e}")
        finally:
            conn.close()
            with self.clients_lock:
                if conn in self.clients:
                    del self.clients[conn]
            if username:
                self.log(f"[DISCONNECTED] {username}")
                self.broadcast_user_list()

    def run(self):
        self.log(f"[SERVER] Listening on {self.host}:{self.port}")
        try:
            while True:
                conn, addr = self.server_socket.accept()
                threading.Thread(target=self.handle_client, args=(conn, addr), daemon=True).start()
        except (KeyboardInterrupt, OSError):
            pass
        finally:
            try:
                self.server_socket.close()
            except:
                pass

if __name__ == "__main__":
    server = Server()
    server.run()
