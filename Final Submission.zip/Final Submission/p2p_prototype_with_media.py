import socket
import threading
import time
import sys
import os

BUFFER_SIZE = 4096
ACK_TIMEOUT = 2
KEEP_ALIVE_INTERVAL = 10
CHUNK_SIZE = 1024


class P2PClient:
    def __init__(self, username, local_port, peer_ip, peer_port):
        self.username = username
        self.local_port = int(local_port)
        self.peer_address = (peer_ip, int(peer_port))

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", self.local_port))

        self.sequence_number = 0
        self.pending_acks = {}
        self.pending_acks_lock = threading.Lock()  # FIX Bug 8: lock for pending_acks
        self.running = True

        # File reception state
        self.receiving_file = False
        self.file_handle = None
        self.expected_file_size = 0
        self.received_bytes = 0

        print(f"[INFO] {self.username} listening on UDP port {self.local_port}")

    # =====================================================
    # Utilities
    # =====================================================

    def build_header(self, msg_type, seq, extra=""):
        header = f"{msg_type}|{seq}|{self.username}|{extra}|"
        return header.encode()

    def parse_message(self, data):
        # FIX Bug 7: safely parse with validation
        try:
            parts = data.split(b"|", 4)
            if len(parts) < 4:
                return None, None, None, None, None
            msg_type = parts[0].decode()
            seq = int(parts[1].decode())
            sender = parts[2].decode()
            extra = parts[3].decode()
            payload = parts[4] if len(parts) > 4 else b""
            return msg_type, seq, sender, extra, payload
        except (ValueError, UnicodeDecodeError):
            return None, None, None, None, None

    # =====================================================
    # Reliable Send
    # =====================================================

    MAX_RETRIES = 5  # give up after this many resend attempts per packet

    def send_with_reliability(self, raw_message, seq):
        with self.pending_acks_lock:
            self.pending_acks[seq] = {
                "message": raw_message,
                "timestamp": time.time(),
                "retries": 0
            }
        self.sock.sendto(raw_message, self.peer_address)

    def resend_unacked(self):
        while self.running:
            now = time.time()
            with self.pending_acks_lock:
                snapshot = list(self.pending_acks.keys())
            for seq in snapshot:
                with self.pending_acks_lock:
                    entry = self.pending_acks.get(seq)
                if entry and now - entry["timestamp"] > ACK_TIMEOUT:
                    if entry["retries"] >= self.MAX_RETRIES:
                        # Give up silently — send_file's deadline loop will handle the abort
                        with self.pending_acks_lock:
                            self.pending_acks.pop(seq, None)
                        continue
                    self.sock.sendto(entry["message"], self.peer_address)
                    with self.pending_acks_lock:
                        if seq in self.pending_acks:
                            self.pending_acks[seq]["timestamp"] = now
                            self.pending_acks[seq]["retries"] += 1
            time.sleep(1)

    # =====================================================
    # File Sending
    # =====================================================

    def send_file(self, filepath):
        if not os.path.exists(filepath):
            print("[ERROR] File not found")
            return

        filesize = os.path.getsize(filepath)
        filename = os.path.basename(filepath)

        # Send FILE_INFO
        info_seq = self.sequence_number   # snapshot seq before any increment
        header = self.build_header("FILE_INFO", info_seq, f"{filename}:{filesize}")
        self.send_with_reliability(header, info_seq)
        print(f"[SEND] FILE_INFO {filename} ({filesize} bytes)")
        self.sequence_number += 1

        # Wait for FILE_INFO ACK — use 30s timeout to handle internet latency
        print("[SEND] Waiting for peer to acknowledge file transfer...")
        deadline = time.time() + 30
        while time.time() < deadline:
            with self.pending_acks_lock:
                if info_seq not in self.pending_acks:
                    break
            time.sleep(0.2)
        else:
            print("[ERROR] FILE_INFO not acknowledged after 30s. Aborting file send.")
            print("[HINT]  Make sure UDP port 5100 is open/forwarded on both routers.")
            with self.pending_acks_lock:
                self.pending_acks.pop(info_seq, None)  # clean up
            return

        print("[SEND] Peer ready, sending file data...")

        # Send FILE_DATA chunks
        with open(filepath, "rb") as f:
            while True:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break

                seq = self.sequence_number
                header = self.build_header("FILE_DATA", seq)
                message = header + chunk

                self.send_with_reliability(message, seq)
                print(f"[SEND] FILE_DATA SEQ={seq}")

                self.sequence_number += 1
                time.sleep(0.01)

        print("[FILE SEND COMPLETE]")

    # =====================================================
    # Listener
    # =====================================================

    def listener(self):
        while self.running:
            try:
                data, addr = self.sock.recvfrom(BUFFER_SIZE)
                msg_type, seq, sender, extra, payload = self.parse_message(data)

                # FIX Bug 7: skip malformed packets
                if msg_type is None:
                    continue

                if msg_type == "ACK":
                    with self.pending_acks_lock:  # FIX Bug 8
                        if seq in self.pending_acks:
                            del self.pending_acks[seq]
                            print(f"[ACK RECEIVED] SEQ={seq}")

                elif msg_type == "FILE_INFO":
                    filename, filesize = extra.split(":")
                    filesize = int(filesize)

                    # FIX Bug 5: close any previously open file handle before starting new
                    if self.file_handle and not self.file_handle.closed:
                        self.file_handle.close()
                        print("[WARN] Previous file transfer interrupted, starting new one.")

                    self.file_handle = open("received_" + filename, "wb")
                    self.expected_file_size = filesize
                    self.received_bytes = 0
                    self.receiving_file = True

                    print(f"[RECEIVING FILE] {filename} ({filesize} bytes)")

                    ack = self.build_header("ACK", seq)
                    self.sock.sendto(ack, addr)

                elif msg_type == "FILE_DATA" and self.receiving_file:
                    self.file_handle.write(payload)
                    self.received_bytes += len(payload)

                    ack = self.build_header("ACK", seq)
                    self.sock.sendto(ack, addr)

                    if self.received_bytes >= self.expected_file_size:
                        self.file_handle.close()
                        self.receiving_file = False
                        print("[FILE RECEIVED COMPLETE]")

                elif msg_type == "CHAT_MSG":
                    print(f"[CHAT] {sender}: {extra}")
                    ack = self.build_header("ACK", seq)
                    self.sock.sendto(ack, addr)

            except OSError:
                # FIX Bug 5: on socket error, clean up any open file handle
                if self.file_handle and not self.file_handle.closed:
                    self.file_handle.close()
                    self.receiving_file = False
                continue
            except Exception:
                continue

    # =====================================================
    # Chat
    # =====================================================

    def send_chat(self, text):
        seq = self.sequence_number
        header = self.build_header("CHAT_MSG", seq, text)
        self.send_with_reliability(header, seq)
        self.sequence_number += 1

    # =====================================================
    # Start
    # =====================================================

    def start(self):
        threading.Thread(target=self.listener, daemon=True).start()
        threading.Thread(target=self.resend_unacked, daemon=True).start()

        while True:
            cmd = input("Enter message (/file path /quit): ")

            if cmd.startswith("/file"):
                _, path = cmd.split(" ", 1)
                self.send_file(path)

            elif cmd == "/quit":
                self.running = False
                break

            else:
                self.send_chat(cmd)


# =====================================================
# Main
# =====================================================

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python p2p.py <username> <local_port> <peer_ip> <peer_port>")
        sys.exit(1)

    username = sys.argv[1]
    local_port = sys.argv[2]
    peer_ip = sys.argv[3]
    peer_port = sys.argv[4]

    client = P2PClient(username, local_port, peer_ip, peer_port)
    client.start()
