import socket
import threading
import json


class Client:
    def __init__(self, host='127.0.0.1', port=5005):
        self.host = host
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect((self.host, self.port))
        self.ping = True
        self._quitting = False
        self._callback = None
        self._buffer = ""

    def login(self, username, public=True, p2p_port=5100):
        self._send_json({"type": "LOGIN", "username": username, "public": public, "p2p_port": p2p_port})

    def _send_json(self, obj):
        try:
            data = json.dumps(obj)
            self.client_socket.send((data + "\n").encode('utf-8'))
            return True
        except:
            return False

    def send_group(self, text):
        return self._send_json({"type": "GROUP_MSG", "text": text})

    def send_private(self, target, text):
        return self._send_json({"type": "PRIVATE_MSG", "target": target, "text": text})

    def send_ping(self):
        return self._send_json({"type": "PING"})

    def set_visibility(self, public, p2p_port=5100):
        return self._send_json({"type": "SET_VISIBILITY", "public": public, "p2p_port": p2p_port})

    def send_connect_request(self, target):
        return self._send_json({"type": "CONNECT_REQUEST", "target": target})

    def send_connect_response(self, target, accepted):
        return self._send_json({"type": "CONNECT_RESPONSE", "target": target, "accepted": accepted})

    def receive_messages(self, callback=None):
        self._callback = callback
        while self.ping:
            try:
                chunk = self.client_socket.recv(4096).decode('utf-8')
                if not chunk:
                    break
                self._buffer += chunk
                while "\n" in self._buffer:
                    line, self._buffer = self._buffer.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        if callback:
                            callback(msg)
                    except:
                        pass
            except (OSError, ConnectionResetError, ConnectionAbortedError):
                if not self._quitting and callback:
                    callback({"type": "SYSTEM", "text": "[ERROR] Connection lost."})
                self.ping = False
                break

    def disconnect(self):
        self._quitting = True
        self.ping = False
        try:
            self.client_socket.close()
        except:
            pass

    def run(self, callback=None):
        thread = threading.Thread(target=self.receive_messages, args=(callback,), daemon=True)
        thread.start()
